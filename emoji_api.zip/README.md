# Django REST API Template

A simple Django REST Framework API with:
- Token-based Authentication
- User Registration & Login with Roles
- CRUD for Emojis, Categories, Posts
- Post editing restricted to author
- Standardized API responses
- SQLite as default DB

---

## 🚀 Setup Instructions

```bash
git clone <your-repo>  # or unzip if downloaded
cd drf_api_template

# Create virtual environment
python3 -m venv venv
source venv/bin/activate

# Install dependencies
pip install django djangorestframework djangorestframework-simplejwt

# Migrate and create admin user
python manage.py makemigrations
python manage.py makemigrations api

python manage.py migrate
python manage.py createsuperuser

# (Optional) Seed the database
python manage.py shell
>>> from api.seeds import seed
>>> seed()
>>> exit()

# Run server
python manage.py runserver
```

---

## 🔐 Authentication

All endpoints require `Token` auth.
Send token in the header:

```
Authorization: Token your_token_here
```

---

## 🧪 API Endpoints

### 🔑 Register

**POST /api/auth/register/**

```json
{
  "username": "john",
  "password": "pass123",
  "email": "john@example.com"
}
```

**Response:**
```json
{
  "data": {
    "token": "abc123",
    "user": {
      "id": 1,
      "username": "john",
      "email": "john@example.com",
      "role": "user"
    }
  },
  "message": "Registered successfully",
  "errors": ""
}
```

---

### 🔑 Login

**POST /api/auth/login/**

```json
{
  "username": "john",
  "password": "pass123"
}
```

---

## 😄 Emojis

| Method | Endpoint         | Description         |
|--------|------------------|---------------------|
| GET    | /api/emojis/     | List all emojis     |
| POST   | /api/emojis/     | Create emoji        |
| PUT    | /api/emojis/:id/ | Update emoji        |
| DELETE | /api/emojis/:id/ | Delete emoji        |

---

## 📂 Categories

| Method | Endpoint              | Description           |
|--------|-----------------------|-----------------------|
| GET    | /api/categories/      | List all categories   |
| POST   | /api/categories/      | Create category       |
| PUT    | /api/categories/:id/  | Update category       |
| DELETE | /api/categories/:id/  | Delete category       |

---

## 📝 Posts

> Only the author can update/delete their posts.

| Method | Endpoint         | Description        |
|--------|------------------|--------------------|
| GET    | /api/posts/      | List all posts     |
| POST   | /api/posts/      | Create post        |
| PUT    | /api/posts/:id/  | Update post        |
| DELETE | /api/posts/:id/  | Delete post        |

**Sample Create:**
```json
{
  "title": "My Post",
  "content": "Hello world!",
  "category": 1
}
```

---

## 🔁 Response Format

All endpoints return:

```json
{
  "data": { ... },
  "message": "Success or info",
  "errors": "Validation or error details"
}
```

---

## 👤 Roles

- `user` – default for registered users
- `admin` – manually set in Django admin

---

## 📦 Seed Users

| Username | Password   | Role  |
|----------|------------|-------|
| test     | pass123    | user  |
| admin    | admin123   | admin |

---

Happy coding! 🎉
