from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import EmojiViewSet, CategoryViewSet, PostViewSet, register, login

router = DefaultRouter()
router.register('emojis', EmojiViewSet)
router.register('categories', CategoryViewSet)
router.register('posts', PostViewSet)

urlpatterns = [
    path('auth/register/', register),
    path('auth/login/', login),
    path('', include(router.urls)),
]
