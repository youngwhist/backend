from rest_framework import viewsets
from rest_framework.decorators import api_view
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.authtoken.models import Token
from django.contrib.auth import authenticate
from .models import Emoji, Post, Category, User
from .serializers import EmojiSerializer, PostSerializer, CategorySerializer, UserSerializer
from .permissions import IsAuthorOrReadOnly

def format_response(data=None, message="", errors=""):
    return Response({"data": data, "message": message, "errors": errors})

class EmojiViewSet(viewsets.ModelViewSet):
    queryset = Emoji.objects.all()
    serializer_class = EmojiSerializer
 

    def list(self, request):
        serializer = self.get_serializer(self.get_queryset(), many=True)
        return format_response(data=serializer.data)

class CategoryViewSet(viewsets.ModelViewSet):
    queryset = Category.objects.all()
    serializer_class = CategorySerializer
    permission_classes = [IsAuthenticated]

    def list(self, request):
        serializer = self.get_serializer(self.get_queryset(), many=True)
        return format_response(data=serializer.data)

class PostViewSet(viewsets.ModelViewSet):
    queryset = Post.objects.all()
    serializer_class = PostSerializer
    permission_classes = [IsAuthenticated, IsAuthorOrReadOnly]

    def perform_create(self, serializer):
        serializer.save(author=self.request.user)

    def list(self, request):
        serializer = self.get_serializer(self.get_queryset(), many=True)
        return format_response(data=serializer.data)

@api_view(['POST'])
def register(request):
    username = request.data.get('username')
    password = request.data.get('password')
    email = request.data.get('email')
    if not username or not password:
        return format_response(errors="Username and password are required")
    user = User.objects.create_user(username=username, password=password, email=email)
    token, _ = Token.objects.get_or_create(user=user)
    return format_response(data={'token': token.key, 'user': UserSerializer(user).data}, message="Registered successfully")

@api_view(['POST'])
def login(request):
    username = request.data.get('username')
    password = request.data.get('password')
    user = authenticate(username=username, password=password)
    if user:
        token, _ = Token.objects.get_or_create(user=user)
        return format_response(data={'token': token.key, 'user': UserSerializer(user).data}, message="Login successful")
    return format_response(errors="Invalid credentials")
